Work Division:

Part A: Alvin Lim
Part B: Jennifer Jo
Part C: Both worked on it.
Part D: Ended partnership; worked separately halfway through.