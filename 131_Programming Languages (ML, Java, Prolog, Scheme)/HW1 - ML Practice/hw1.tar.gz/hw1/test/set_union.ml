let set_union_test0_a6b9b17503dcd9b5b8e8ad16da46c432 = equal_sets (set_union [] [1;2;3]) [1;2;3]
let set_union_test1_a6b9b17503dcd9b5b8e8ad16da46c432 = equal_sets (set_union [3;1;3] [1;2;3]) [1;2;3]
let set_union_test2_a6b9b17503dcd9b5b8e8ad16da46c432 = equal_sets (set_union [] []) []
