let subset_test0_a6b9b17503dcd9b5b8e8ad16da46c432 = subset [] [1;2;3]
let subset_test1_a6b9b17503dcd9b5b8e8ad16da46c432 = subset [3;1;3] [1;2;3]
let subset_test2_a6b9b17503dcd9b5b8e8ad16da46c432 = not (subset [1;3;7] [4;1;3])
