-- ALTER TABLE ItemLocation DROP INDEX spatial_index;
DROP TABLE IF EXISTS ItemLocation;